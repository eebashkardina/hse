library(readr)
library(formattable)
library(dplyr)
library(MASS)
library(haven)
library(ggplot2)
library(shinythemes)
library(forcats)
library(gridExtra)
library(caret)

library("wesanderson")
library(shiny)
library(shinybusy)
library(shinyjs)

load("~/shared/minor3_2019_15/datasets/hse19.rds")
load("~/shared/minor3_2019_15/datasets/ege3_all.rds")
load("~/shared/minor3_2019_15/datasets/ege4_all.rds")

jscode <- "shinyjs.refresh = function()"

ui <- fluidPage(theme = shinytheme("readable"),
                
                tags$head(
                    tags$style(HTML("
      .shiny-output-error-validation {
        color: red;
      }
    "))
                ),
                
                shinyjs::useShinyjs(),
                shinyjs::extendShinyjs(text = "shinyjs.refresh = function() { location.reload(); }"),
                
                navlistPanel("Хочу в Вышку!",
                          tabPanel(h3("О приложении"), 
                                   h4(p("Приложение", span("Хочу в Вышку", style = "color:blue"), "разработано для предсказания поступления на бюджет в Московский кампус Высшей Школы Экономики."), 
                                      p("Приложение состоит из двух частей: статистической и предсказательной. В разделе", span("Статистика", style = "color:blue"), "ты можешь найти статистику поступлений на бюджет абитуриентов за 2017-2019 года. 
                                     Ты узнаешь какие факторы увеличивают шансы поступления на бюджет. Среди представленных факторов: социально-демографические, результаты анкетирования абитуриентов, оценочные суждения о высшем образовании."),
                                      p("В разделе", span("Проверь свои шансы", style = "color:blue"), "ты сможешь посчитать вероятность поступления на бюджет, ответив на несколько вопросов, а также выяснить как твои ответы повлияли на шансы поступления."),
                                      align = "center"), 
                                   hr(),
                                   img(src = "Логотип_НИУ_ВШЭ.jpg", height = 400, width = 398, style="display: block; margin-left: auto; margin-right: auto;")),
                          tabPanel(h3("Статистика"),  navlistPanel(
                            "Make a choice",
                            tabPanel("На основе социально-демографической информации об абитуриентах",
                                     h3(plotOutput("treea"),
                                        plotOutput("treeb"),
                                        plotOutput("treec"),
                                        plotOutput("treed"))
                            ),
                            tabPanel("На основе результатов анкетирования абитуриентов",
                                     h3(plotOutput("treee"), plotOutput("treef"), plotOutput("treeg"), plotOutput("treeh"),plotOutput("one"), plotOutput("two"), plotOutput("three"), plotOutput("four"), plotOutput("five"), plotOutput("six"), plotOutput("gr1"), plotOutput("gr2"), plotOutput("gr3"), plotOutput("gr4"))
                            ),
                            tabPanel("На основе результатов оценочных суждений о высшем образовании в целом",
                                     h3(plotOutput("graph1"), plotOutput("graph2"), plotOutput("graph3"), plotOutput("graph4"))
                            )
                          )
                          ),
                           tabPanel(h3("Проверь свои шансы"),
                                    tabsetPanel(
                                        tabPanel(("Для тех, кто сдавал три предмета ЕГЭ"),
                                    
                                        radioButtons("radio2", label = h4("Как давно Вы решили, что будете поступать в НИУ ВШЭ?"),
                                                     choices = list("Менее половины учебного года назад" = "lessthanHalf", "Около полугода назад" = "aboutHalfAgo", "Более 1 учебного года назад" = "about1yearAgo"), 
                                                     selected = 1),
                                        
                                        hr(),
                                        fluidRow(column(3, verbatimTextOutput("value2"))),
                                        radioButtons("radio3", label = h4("Есть ли у вас приоритетная ОП в НИУ ВШЭ?"),
                                                     choices = list("Да" = "yes", "Нет" = "no"), 
                                                     selected = 1),
                                        
                                        hr(),
                                        fluidRow(column(2, verbatimTextOutput("value3"))),
                                        radioButtons("radio4", label = h4("Есть ли у вас приоритеные ВУЗы?"),
                                                     choices = list("Да, один" = "one", "Да, два" = "two", "Приоритетного ВУЗа нет" = "none"), 
                                                     selected = 1),
                                        
                                        hr(),
                                        fluidRow(column(3, verbatimTextOutput("value4"))),
                                        radioButtons("radio5", label = h4("Что для Вас важнее: поступить в конкретный вуз или на конкретное направление подготовки?"),
                                                     choices = list("Важно поступить на конкретное направление подготовки в конкретный ВУЗ" = "1ОП1В", "Важно поступить в конкретный ВУЗ на любое направление подготовки" = "ЛОП1В", "Важно поступить на конкретное направление подготовки в любой ВУЗ" = "1ОПЛВ"), 
                                                     selected = 1),
                                        
                                        hr(),
                                        fluidRow(column(3, verbatimTextOutput("value5"))),
                                        sliderInput("radio6", label = h4("Введи сумму баллов ЕГЭ за 3 предмета, которые вы сдавали. Если вы ещё не знаете результатов, введите ту сумму, которую вы предполагаете получить (основываясь на результатах пробных ЕГЭ в школе и т.д.)"), min = 180, max = 310, value = 230),
                                        
                                        
                                        actionButton("action3", label = "Результат"),
                                        textOutput("distPlot3"),
                                        hr(),
                                        fluidRow(column(2, verbatimTextOutput(textOutput("distPlot3")))),
                                        
                                        actionButton("action5", label = "А почему так? Хочу узнать больше!"),
                                        plotOutput("distPlot7"),
                                        htmlOutput("distPlot8"),
                                        hr() ,
                                        actionButton("refresh1", "Попробовать ещё раз")
                                        ),
                                    
            tabPanel(("Для тех, кто сдавал четыре предмета ЕГЭ"),  radioButtons("radio7", label = h4("Как давно Вы решили, что будете поступать в НИУ ВШЭ?"),
                                                                                                choices = list("Менее половины учебного года назад" = "lessthanHalf", "Около полугода назад" = "aboutHalfAgo", "Более 1 учебного года назад" = "about1yearAgo"), 
                                                                                                selected = 1),
                                    
                                    hr(),
                                    fluidRow(column(3, verbatimTextOutput("value7"))),
                                    radioButtons("radio8", label = h4("Есть ли у вас приоритетная ОП в НИУ ВШЭ?"),
                                                 choices = list("Да" = "yes", "Нет" = "no"), 
                                                 selected = 1),
                                    
                                    hr(),
                                    fluidRow(column(2, verbatimTextOutput("value8"))),
                                    radioButtons("radio9", label = h4("Есть ли у вас приоритеные ВУЗы?"),
                                                 choices = list("Да, один" = "one", "Да, два" = "two", "Приоритетного ВУЗа нет" = "none"), 
                                                 selected = 1),
                                    
                                    hr(),
                                    fluidRow(column(3, verbatimTextOutput("value9"))),
                                    radioButtons("radio0", label = h4("Что для Вас важнее: поступить в конкретный вуз или на конкретное направление подготовки?"),
                                                 choices = list("Важно поступить на конкретное направление подготовки в конкретный ВУЗ" = "1ОП1В", "Важно поступить в конкретный ВУЗ на любое направление подготовки" = "ЛОП1В", "Важно поступить на конкретное направление подготовки в любой ВУЗ" = "1ОПЛВ"), 
                                                 selected = 1),
                                    
                                    hr(),
                                    fluidRow(column(3, verbatimTextOutput("value0"))),
                     sliderInput("radioq", label = h4("Введи сумму баллов ЕГЭ за 4 предмета, которые вы сдавали. Если вы ещё не знаете результатов, введите ту сумму, которую вы предполагаете получить (основываясь на результатах пробных ЕГЭ в школе и т.д.)"), min = 240, max = 410, value = 270),
                                    
                                    

                     actionButton("action4", label = "Результат"),
                     textOutput("distPlot4"),
                     
                     hr(),
                     fluidRow(column(2, verbatimTextOutput(textOutput("distPlot4")))),
                     
                     actionButton("action6", label = "А почему так? Хочу узнать больше!"),
                     plotOutput("distPlot9"),
                     htmlOutput("distPlotq"),
                     hr(),
                     actionButton("refresh2", "Попробовать ещё раз")
                     
                     
                     
)))))

# Define server logic required to draw a histogram
server <- function(input, output, session) {
  
   
  
    output$distPlot3 <- eventReactive(input$action3, {
      
      validate(
        need(input$radio2 != "" | input$radio3 != "" | input$radio4 != "" | input$radio5 != "" | input$radio6 != "", 
             "Ответьте на все вопросы!")
        )
       
      show_modal_spinner(
        spin = "radar",
        color = "darkblue",
        text = "Подождите, пожалуйста!"
      )
      
        set.seed(9383)
        training.samples <- ege3_all$adm_budget %>% 
            createDataPartition(p = 0.8, list = FALSE)
        train.data3  <- ege3_all[training.samples, ]
        test.data3 <- ege3_all[-training.samples, ]
        model_final_all_3 <- glm(adm_budget ~., data = train.data3, family = binomial)
        nemes3 = c("dec","prior_1","uni_2","uni_3","mean_points")
        polar_data3 = c(input$radio2, input$radio3, input$radio4, input$radio5,input$radio6)
        
        polar_user3 = as.data.frame(t(polar_data3))
        colnames(polar_user3) <- nemes3
        
        polar_user3$mean_points = as.numeric(as.character(polar_user3$mean_points))
        probabilities3 <- model_final_all_3 %>% predict(test.data3, type = "response")
        predicted.classes3 <- ifelse(probabilities3 > 0.5, "yes", "no")
        # Prediction accuracy
        observed.classes3<- test.data3$adm_budget
        logMod_all_3 = train(adm_budget ~ ., data = train.data3, method = "glm", family = binomial)
        polar_user_pred3 = predict(logMod_all_3, polar_user3, type = "prob")[,2]
        polar3 = round(polar_user_pred3*1.716*100, 3)
        polarr3 = sprintf("Ваша вероятность поступления на бюджет в НИУ ВШЭ (Москва) составляет  %.3f%%. Вероятность может увеличиться при поступлении в другие кампусы НИУ ВШЭ.", polar3)
        
        remove_modal_spinner()
        polarr3
    })
    
    output$distPlot4 <- eventReactive(input$action4, {
      
      validate(
        need(input$radio7 != "" | input$radio8 != "" | input$radio9 != "" | input$radio0 != "" | input$radioq != "", 
             "Ответьте на все вопросы!")
      )
      
      show_modal_spinner(
        spin = "fulfilling-square",
        color = "darkblue",
        text = "Подождите, пожалуйста!"
      )
      
        set.seed(9383)
        training.samples <- ege4_all$adm_budget %>% 
            createDataPartition(p = 0.8, list = FALSE)
        train.data4  <- ege4_all[training.samples, ]
        test.data4 <- ege4_all[-training.samples, ]
        
        
        model_final_all_4 <- glm(adm_budget ~., data = train.data4, family = binomial)
        summary(model_final_all_4)
        
        nemes4 = c("dec","prior_1","uni_2","uni_3","mean_points")
        polar_data4 = c(input$radio7, input$radio8, input$radio9, input$radio0,input$radioq)
        polar_user4 = as.data.frame(t(polar_data4))
        colnames(polar_user4) <- nemes4
        polar_user4$mean_points = as.numeric(as.character(polar_user4$mean_points))
    
        # Make predictions
        probabilities4 <- model_final_all_4 %>% predict(test.data4, type = "response")
        predicted.classes4 <- ifelse(probabilities4 > 0.5, "yes", "no")
        # Prediction accuracy
        observed.classes4 <- test.data4$adm_budget
     
        logMod_all_4 = train(adm_budget ~ ., data = train.data4, method = "glm", family = binomial)
        
        polar_user_pred4= predict(logMod_all_4, polar_user4, type = "prob")[,2]
        polar4 = round(polar_user_pred4*1.3*100, 3)
        polarr4= sprintf("Ваша вероятность поступления на бюджет в НИУ ВШЭ (Москва) составляет %.3f%%. Вероятность может увеличиться при поступлении в другие кампусы НИУ ВШЭ." , polar4)
        
        remove_modal_spinner()
        polarr4
     
    })
    
    distPlot7 <- eventReactive(input$action5, { 
      
      validate(
        need(input$radio2 != "" | input$radio3 != "" | input$radio4 != "" | input$radio5 != "" | input$radio6 != "", 
             "Ответьте на все вопросы!")
      )
      
      show_modal_spinner(
        spin = "radar",
        color = "darkblue",
        text = "Подождите, пожалуйста!"
      )
      
        set.seed(9383)
        training.samples <- ege3_all$adm_budget %>% 
            createDataPartition(p = 0.8, list = FALSE)
        train.data3  <- ege3_all[training.samples, ]
        test.data3 <- ege3_all[-training.samples, ]
        model_final_all_3 <- glm(adm_budget ~., data = train.data3, family = binomial)
        nemes3 = c("dec","prior_1","uni_2","uni_3","mean_points")
        polar_data3 = c(input$radio2, input$radio3, input$radio4, input$radio5,input$radio6)
        
        polar_user3 = as.data.frame(t(polar_data3))
        colnames(polar_user3) <- nemes3
        
        polar_user3$mean_points = as.numeric(as.character(polar_user3$mean_points))
        probabilities3 <- model_final_all_3 %>% predict(test.data3, type = "response")
        predicted.classes3 <- ifelse(probabilities3 > 0.5, "yes", "no")
        # Prediction accuracy
        observed.classes3<- test.data3$adm_budget
        logMod_all_3 = train(adm_budget ~ ., data = train.data3, method = "glm", family = binomial)
        
        
        
        logPred_all_3 = predict(logMod_all_3, test.data3, type = "prob") #полный дф
        #добавила тройку и там и там
        options(scipen = 999)
        logPred_all_3 = predict(logMod_all_3, test.data3, type = "prob")[ ,2] #вероятность поступления на бюджет (вероятность adm_budget == `yes`)
        all_probs_3 <- as.data.frame(logPred_all_3)
        all_probs_3$logPred_all_3 = round(all_probs_3$logPred_all_3,3)
        
        #добавляем результат
        nemes_with_result = c("dec","prior_1","uni_2","uni_3","mean_points", "adm_budget") 
        polar_data_with_result = c(input$radio2, input$radio3, input$radio4, input$radio5,input$radio6, "no")
        
        polar_user_with_result = as.data.frame(t(polar_data_with_result))
        colnames(polar_user_with_result) <- nemes_with_result
        
        polar_user_with_result$mean_points = as.numeric(as.character(polar_user_with_result$mean_points))
        
        test.data3.withNewUser = rbind(test.data3, polar_user_with_result) #приклеиваем к тестовой выборке
        
        library(lime)
        
        # создаем объект для дальнейшего объяснения с данными, на которых была построена модель, и самой моделью
        explain_logreg = lime(x = train.data3, model = logMod_all_3)
        
        # объясняем конкретный пример
        explain_ex_log = lime::explain(x = test.data3.withNewUser[3212, ], 
                                       explainer = explain_logreg,
                                       n_features = 6,
                                       n_labels = 1)
        remove_modal_spinner()
        
        plot_features(explain_ex_log) 
        
    })
    output$distPlot7<- renderPlot({ 
        
        plot(distPlot7())
        
    })
    
    output$distPlot8 <- eventReactive(input$action5, { 
      
      if (
        is.null(input$radio2)|is.null(input$radio3)|is.null(input$radio4)|is.null(input$radio5)|is.null(input$radio6)
      ) {
        ""
      } else {
        
        paste("Вы смотрите на график того, как выбранные вами значения каждой переменной повлияли на конечный исход предсказания.<p> 
        <b>Label: no</b> означает, что на графике изображено, как факторы повлияли на исход “НЕ ПОСТУПИЛ”. Зеленым цветом обозначены переменные, которые увеличили вероятность исхода “НЕ ПОСТУПИЛ”, а красным - которые уменьшили эту вероятность, то есть положительно повлияли на Ваш шанс поступить.<p>
        <b>Label: yes</b> означает, что на графике показано, как Ваш выбор повлиял на исход “ПОСТУПИЛ”. Зеленым цветом обозначены переменные, которые увеличили вероятность исхода “ПОСТУПИЛ”, а красным - которые уменьшили эту вероятность, то есть снизили Ваш шанс поступить."
        )
        }
      })
    
    observeEvent(input$refresh1, {
      js$refresh();
    })
    
    
    distPlot9 <- eventReactive(input$action6, { 
      
      validate(
        need(input$radio7 != "" | input$radio8 != "" | input$radio9 != "" | input$radio0 != "" | input$radioq != "", 
             "Ответьте на все вопросы!")
      )
      
      show_modal_spinner(
        spin = "fulfilling-square",
        color = "darkblue",
        text = "Подождите, пожалуйста!"
      )
        
        set.seed(9383)
        training.samples <- ege4_all$adm_budget %>% 
            createDataPartition(p = 0.8, list = FALSE)
        train.data4  <- ege4_all[training.samples, ]
        test.data4 <- ege4_all[-training.samples, ]
        
        model_final_all_4 <- glm(adm_budget ~., data = train.data4, family = binomial)
        nemes4 = c("dec","prior_1","uni_2","uni_3","mean_points")
        
        polar_data4 = c(input$radio7, input$radio8, input$radio9, input$radio0,input$radioq)
        polar_user4 = as.data.frame(t(polar_data4))
        colnames(polar_user4) <- nemes4
        polar_user4$mean_points = as.numeric(as.character(polar_user4$mean_points))
        
        probabilities4 <- model_final_all_4 %>% predict(test.data4, type = "response")
        predicted.classes4 <- ifelse(probabilities4 > 0.5, "yes", "no")
        # Prediction accuracy
        observed.classes4 <- test.data4$adm_budget
        
        logMod_all_4 = train(adm_budget ~ ., data = train.data4, method = "glm", family = binomial)
        
        logPred_all_4 = predict(logMod_all_4, test.data4, type = "prob")
        options(scipen = 999)
        logPred_all_4 = predict(logMod_all_4, test.data4, type = "prob")[ ,2] #вероятность поступления на бюджет (вероятность adm_budget == `yes`)
        all_probs_4 <- as.data.frame(logPred_all_4)
        all_probs_4$logPred_all_4 = round(all_probs_4$logPred_all_4,3)
        
        #добавляем результат
        nemes_with_result4 = c("dec","prior_1","uni_2","uni_3","mean_points", "adm_budget") 
        polar_data_with_result4 = c(input$radio7, input$radio8, input$radio9, input$radio0,input$radioq, "no")
        
        polar_user_with_result4 = as.data.frame(t(polar_data_with_result4))
        colnames(polar_user_with_result4) <- nemes_with_result4
        
        polar_user_with_result4$mean_points = as.numeric(as.character(polar_user_with_result4$mean_points))
        
        test.data4.withNewUser = rbind(test.data4, polar_user_with_result4) #приклеиваем к тестовой выборке
        
        library(lime)
        
        # создаем объект для дальнейшего объяснения с данными, на которых была построена модель, и самой моделью
        explain_logreg4 = lime(x = train.data4, model = logMod_all_4)
        
        # объясняем конкретный пример
        explain_ex_log4 = lime::explain(x = test.data4.withNewUser[1886, ], 
                                       explainer = explain_logreg4,
                                       n_features = 6,
                                       n_labels = 1)
      
        remove_modal_spinner()  
        plot_features(explain_ex_log4) 
        
        
    })
    output$distPlot9<- renderPlot({ 
        plot(distPlot9())
    })
    
    output$distPlotq <- eventReactive(input$action6, { 
      
      if (
        is.null(input$radio7)|is.null(input$radio8)|is.null(input$radio9)|is.null(input$radio0)|is.null(input$radioq)
      ) {
        ""
      } else {
        paste("Вы смотрите на график того, как выбранные вами значения каждой переменной повлияли на конечный исход предсказания.<p> 
        <b>Label: no</b> означает, что на графике изображено, как факторы повлияли на исход “НЕ ПОСТУПИЛ”. Зеленым цветом обозначены переменные, которые увеличили вероятность исхода “НЕ ПОСТУПИЛ”, а красным - которые уменьшили эту вероятность, то есть положительно повлияли на Ваш шанс поступить.<p>
        <b>Label: yes</b> означает, что на графике показано, как Ваш выбор повлиял на исход “ПОСТУПИЛ”. Зеленым цветом обозначены переменные, которые увеличили вероятность исхода “ПОСТУПИЛ”, а красным - которые уменьшили эту вероятность, то есть снизили Ваш шанс поступить."
        )
        }
      })
   
    observeEvent(input$refresh2, {
      js$refresh();
    })
     
   
    modeling <- reactive({
      region_top = hse19 %>% group_by(`Region$D`) %>% summarise(count = n()) %>% top_n(10,count)
      
      region = hse19 %>% filter(`Region$D` %in% region_top$`Region$D`) %>% group_by(`Region$D`, adm_budget) %>% summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1)) %>% select(`Region$D`, adm_budget, count, perc) %>% group_by(adm_budget) %>% arrange(perc)%>%
        mutate(`Region$D`=factor(`Region$D`, levels=`Region$D`))
      
      #region %>% select(`Region$D`, adm_budget, count, perc) %>% na.omit() %>% group_by(adm_budget) %>% arrange(-perc) %>% mutate(`Region$D`=factor(`Region$D`, levels=`Region$D`))
      
      c <- ggplot(data = region, aes(x = `Region$D`, y = count, fill = fct_rev(adm_budget))) +
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill")+
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "          %")), 
                  y = 0.07, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", 
                                     perc, "           %")), y = 0.8, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Распределение поступивших на бюджет\nв Топ 10 наиболее популярных регионах
", y = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        coord_flip()+
        # scale_fill_manual(values = wes_palette("Rushmore1")[2:3])+
        theme(text = element_text(size = 10),
              plot.title = element_text(hjust = 1), title = element_text(size = 10))
    })
    modeling3 <- reactive({
      age = hse19 %>%  
        group_by(Age, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),2))
      
      a <-ggplot(data = na.omit(subset(age, select = c(Age, adm_budget, count, perc))), 
                 aes(x = Age, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") + 
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "             %")), y = 0.1, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", perc, "             %")), y = 0.7, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Распределение поступивших на бюджет\nпо возрасту
            ", y  = "", x = "Возраст") +
        theme_minimal() +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 10),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
      a
    })
    modeling2 <- reactive({
      
      hse19$Sex[hse19$Sex == 1] = "М"
      hse19$Sex[hse19$Sex == 0] = "Ж"
      hse19$Sex = as.factor(hse19$Sex)
      
      gender = hse19 %>%  
        group_by(Sex, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      b <- ggplot(data = na.omit(subset(gender, select = c(Sex, adm_budget, count, perc))), 
                  aes(x = Sex, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") + 
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "             %")), y = 0.1, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", perc, "             %")), y = 0.7, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Распределение поступивших\nна бюджет по полу
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill=guide_legend(title= "Результат поступления:"))+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 10),
              plot.title = element_text(hjust = 0.1), title = element_text(size = 10))
      b
    })
    
    modeling <- reactive({
      region_top = hse19 %>% group_by(`Region$D`) %>% summarise(count = n()) %>% top_n(10,count)
      
      region = hse19 %>% filter(`Region$D` %in% region_top$`Region$D`) %>% group_by(`Region$D`, adm_budget) %>% summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1)) %>% dplyr::select(`Region$D`, adm_budget, count, perc) %>% group_by(adm_budget) %>% arrange(perc)%>% mutate(`Region$D`=factor(`Region$D`, levels=`Region$D`))
      
      #region %>% select(`Region$D`, adm_budget, count, perc) %>% na.omit() %>% group_by(adm_budget) %>% arrange(-perc) %>% mutate(`Region$D`=factor(`Region$D`, levels=`Region$D`))
      
      c <- ggplot(data = region, aes(x = `Region$D`, y = count, fill = fct_rev(adm_budget))) +
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill")+
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "          %")), 
                  y = 0.07, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", 
                                     perc, "           %")), y = 0.8, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Распределение поступивших на бюджет\nв Топ 10 наиболее популярных регионах
", y = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        coord_flip()+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 10),
              plot.title = element_text(hjust = 1), title = element_text(size = 10))
    })
    
    modeling1 <- reactive({
      hse19$HostelReq[hse19$HostelReq == 1] = "нужно"
      hse19$HostelReq[hse19$HostelReq == 0] = "не нужно"
      hse19$HostelReq = as.factor(hse19$HostelReq)
      hostel = hse19 %>% filter(`Region$D` != "Москва" & `Region$D` != "Московская область") %>% 
        group_by(HostelReq, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      d <- ggplot(hostel, aes(x = HostelReq, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") + 
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "             %")), y = 0.07, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", perc, "             %")), y = 0.7, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Распределение поступивших на бюджет\nи необходимость общежития
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 10),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
      d
    })
    output$treea <- renderPlot({ 
      plot(modeling3())
    })
    output$treeb <- renderPlot({ 
      plot(modeling2())
    })
    output$treec <- renderPlot({ 
      plot(modeling())
    })
    output$treed <- renderPlot({ 
      plot(modeling1())
    })
    
    
    treee <- reactive({#val_lab(hse19$prep_1)
      hse19$prep_1[hse19$prep_1 == 1] = "да"
      hse19$prep_1[hse19$prep_1 == 98] = "нет"
      hse19$prep_1 = as.factor(hse19$prep_1)
      
      prep_1 = hse19 %>% dplyr::select(prep_1, adm_budget) %>% na.omit() %>%  
        group_by(prep_1, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      e <- ggplot(prep_1, aes(x = prep_1, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") +
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("",perc," %"),"")), y = 0.1, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("",perc,"%"),"")), y = 0.7, size = 3) + 
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("n =",count,""),"")), y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("n =",count,""),"")), y = 0.65, size = 3) +
        
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Занимался ли абитуриент дополнительно\nпри подготовке к поступлению?
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
    })
    output$treee <- renderPlot({ 
      plot(treee())
    })
    
    treef <- reactive({#val_lab(hse19$event)
      hse19$event[hse19$event == 1] = "да"
      hse19$event[hse19$event == 98] = "нет"
      hse19$event[hse19$event == 9] = "нет"
      hse19$event = as.factor(hse19$event)
      
      event = hse19 %>% dplyr::select(event, adm_budget) %>% na.omit() %>%  
        group_by(event, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      f <- ggplot(event, aes(x = event, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") +
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("",perc," %"),"")), y = 0.1, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("",perc,"%"),"")), y = 0.7, size = 3) + 
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("n =",count,""),"")), y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("n =",count,""),"")), y = 0.65, size = 3) +
        
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Участвовал ли абитуриент\nв каких-либо мероприятиях НИУ ВШЭ?
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill=guide_legend(title= "Результат поступления:"))+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
    })
    output$treef <- renderPlot({ 
      plot(treef())
    })
    treeg <- reactive({
      hse19$adv[hse19$adv == 1] = "да"
      hse19$adv[hse19$adv == 98] = "нет"
      hse19$adv = as.factor(hse19$adv)
      
      adv = hse19 %>% dplyr::select(adv, adm_budget) %>% na.omit() %>%  
        group_by(adv, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      g <- ggplot(adv, aes(x = adv, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") +
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("",perc," %"),"")), y = 0.1, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("",perc,"%"),"")), y = 0.7, size = 3) + 
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("n =",count,""),"")), y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("n =",count,""),"")), y = 0.65, size = 3) +
        
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Советовали ли абитуриенту\nпоступать в НИУ ВШЭ?
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
    })
    output$treeg <- renderPlot({ 
      plot(treeg())
    })
    treeh <- reactive({
      #val_lab(hse19$olimp)
      hse19$olimp[hse19$olimp == 1] = "да"
      hse19$olimp[hse19$olimp == 98] = "нет"
      hse19$olimp[hse19$olimp == 2] = "да"
      hse19$olimp[hse19$olimp == 9] = "нет"
      hse19$olimp = as.factor(hse19$olimp)
      
      olimp = hse19 %>% dplyr::select(olimp, adm_budget) %>% na.omit() %>%  
        group_by(olimp, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      h <- ggplot(olimp, aes(x = olimp, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") +
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("",perc," %"),"")), y = 0.1, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("",perc,"%"),"")), y = 0.7, size = 3) + 
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("n =",count,""),"")), y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("n =",count,""),"")), y = 0.65, size = 3) +
        
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Участвовал ли абитуриент во\nВсероссийской Олимпиаде школьников?
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
    })
    output$treeh <- renderPlot({ 
      plot(treeh())
    })
    
    one <- reactive({
      hse19$prep_1_1[hse19$prep_1_1 == 1] = "да"
      hse19$prep_1_1[is.na(hse19$prep_1_1)] = "нет"
      hse19$prep_1_1 = as.factor(hse19$prep_1_1)
      prep_1_1 = hse19 %>% dplyr::select(prep_1_1, adm_budget) %>% group_by(prep_1_1, adm_budget) %>% summarise(count = n())%>% mutate(perc = round((count/sum(count)*100),1)) %>% mutate(lab = "Индивидуальные занятия с учителем из своей школы")
      
      one <- ggplot(prep_1_1, aes(x = prep_1_1, y = count, group = adm_budget)) + 
        geom_col(aes(fill = fct_rev(adm_budget)), color = "black", alpha = 0.5, position = "dodge") +
        geom_text(aes(label= paste("",perc,"%"), group = adm_budget), position=position_dodge(0.9), vjust = -0.5, size = 3)+
        labs(title = "Посещал ли абитуриент индивидуальные\nзанятия с учителем из своей школы?
            ", y  = "", x = "") +
        theme_minimal() +
        scale_y_continuous(breaks = 0:7100*2000, limits = c(0,7100)) +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 9))
      
    })
    output$one <- renderPlot({ 
      plot(one())
    })
    two<- reactive({
      hse19$prep_1_3[hse19$prep_1_3 == 1] = "да"
      hse19$prep_1_3[is.na(hse19$prep_1_3)] = "нет"
      hse19$prep_1_3 = as.factor(hse19$prep_1_3)
      prep_1_3 = hse19 %>% dplyr::select(prep_1_3, adm_budget) %>% group_by(prep_1_3, adm_budget) %>% summarise(count = n())%>% mutate(perc = round((count/sum(count)*100),1)) %>% mutate(lab = "Занятия с репетитором")
      
      two <- ggplot(prep_1_3, aes(x = prep_1_3, y = count, group = adm_budget)) + 
        geom_col(aes(fill = fct_rev(adm_budget)), color = "black", alpha = 0.5, position = "dodge") +
        geom_text(aes(label= paste("",perc,"%"), group = adm_budget), position=position_dodge(0.9), vjust = -0.5, size = 3)+
        labs(title = "Посещал ли абитуриент занятия\nс репетитором?
            ", y  = "", x = "") +
        theme_minimal() +
        scale_y_continuous(breaks = 0:6350*2000, limits = c(0,6350)) +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 9))
      
      
    })
    output$two <- renderPlot({ 
      plot(two())
    })
    three<- reactive({
      hse19$prep_1_4[hse19$prep_1_4 == 1] = "да"
      hse19$prep_1_4[is.na(hse19$prep_1_4)] = "нет"
      hse19$prep_1_4 = as.factor(hse19$prep_1_4)
      prep_1_4 = hse19 %>% dplyr::select(prep_1_4, adm_budget) %>% group_by(prep_1_4, adm_budget) %>% summarise(count = n())%>% mutate(perc = round((count/sum(count)*100),1))%>% mutate(lab = "Посещение дополнительных факультативов в своей школе")
      
      three <- ggplot(prep_1_4, aes(x = prep_1_4, y = count, group = adm_budget)) + 
        geom_col(aes(fill = fct_rev(adm_budget)), color = "black", alpha = 0.5, position = "dodge") +
        geom_text(aes(label= paste("",perc,"%"), group = adm_budget), position=position_dodge(0.9), vjust = -0.5, size = 3)+
        labs(title = "Посещал ли абитуриент\nдополнительные занятия в своей школе?
            ", y  = "", x = "") +
        theme_minimal() +
        scale_y_continuous(breaks = 0:9200*2000, limits = c(0,9200)) +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 9))
    })
    output$three <- renderPlot({ 
      plot(three())
    })
    four<- reactive({
      hse19$prep_1_7[hse19$prep_1_7 == 1] = "да"
      hse19$prep_1_7[is.na(hse19$prep_1_7)] = "нет"
      hse19$prep_1_7 = as.factor(hse19$prep_1_7)
      prep_1_7 = hse19 %>% dplyr::select(prep_1_7, adm_budget) %>% group_by(prep_1_7, adm_budget) %>% summarise(count = n())%>% mutate(perc = round((count/sum(count)*100),1))%>% mutate(lab = "Посещение курсов в центры подготовки к ЕГЭ")
      
      four <- ggplot(prep_1_7, aes(x = prep_1_7, y = count, group = adm_budget)) + 
        geom_col(aes(fill = fct_rev(adm_budget)), color = "black", alpha = 0.5, position = "dodge") +
        geom_text(aes(label= paste("",perc,"%"), group = adm_budget), position=position_dodge(0.9), vjust = -0.5, size = 3)+
        labs(title = "Посещал ли абитуриент курсы \nв центрах подготовки к ЕГЭ?
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        scale_y_continuous(breaks = 0:9700*2000, limits = c(0,9700)) +
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 9))
    })
    output$four <- renderPlot({ 
      plot(four())
    })
    five<- reactive({
      hse19$prep_1_10[hse19$prep_1_10 == 1] = "да"
      hse19$prep_1_10[is.na(hse19$prep_1_10)] = "нет"
      hse19$prep_1_10 = as.factor(hse19$prep_1_10)
      prep_1_10 = hse19 %>% dplyr::select(prep_1_10, adm_budget) %>% group_by(prep_1_10, adm_budget) %>% summarise(count = n())%>% mutate(perc = round((count/sum(count)*100),1))%>% mutate(lab = "Самостоятельная подготовка")
      
      five <- ggplot(prep_1_10, aes(x = prep_1_10, y = count, group = adm_budget)) + 
        geom_col(aes(fill = fct_rev(adm_budget)), color = "black", alpha = 0.5, position = "dodge") +
        geom_text(aes(label= paste("",perc,"%"), group = adm_budget), position=position_dodge(0.9), vjust = -0.5, size = 3)+
        labs(title = "Занимался ли абитуриент \nсамостоятельно?
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        scale_y_continuous(breaks = 0:7100*2000, limits = c(0,7100)) +
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 9))
    })
    output$five <- renderPlot({ 
      plot(five())
    })
    six<- reactive({
      hse19$prep_1_6[hse19$prep_1_6 == 1] = "да"
      hse19$prep_1_6[is.na(hse19$prep_1_6)] = "нет"
      hse19$prep_1_6 = as.factor(hse19$prep_1_6)
      prep_1_6 = hse19 %>% dplyr::select(prep_1_6, adm_budget) %>% group_by(prep_1_6, adm_budget) %>% summarise(count = n())%>% mutate(perc = round((count/sum(count)*100),1))%>% mutate(lab = "Посещение курсов при местных университетах (не НИУ ВШЭ)")
      
      six <- ggplot(prep_1_6, aes(x = prep_1_6, y = count, group = adm_budget)) + 
        geom_col(aes(fill = fct_rev(adm_budget)), color = "black", alpha = 0.5, position = "dodge") +
        geom_text(aes(label= paste("",perc,"%"), group = adm_budget), position=position_dodge(0.9), vjust = -0.5, size = 3)+
        labs(title = "Посещал ли абитуриент курсы\nпри местных университетах?
            ", y  = "", x = "") +
        theme_minimal() +
        scale_y_continuous(breaks = 0:10100*2000, limits = c(0,10100)) +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 9))
    })
    output$six <- renderPlot({ 
      plot(six())
    })
    gr1<- reactive({
      #val_lab(hse19$dec)
      
      hse19$dec[hse19$dec == 1] = "июль"
      hse19$dec[hse19$dec == 2] = "май-июнь"
      hse19$dec[hse19$dec == 3] = "январь-апрель"
      hse19$dec[hse19$dec == 4] = "сентябрь-декабрь"
      hse19$dec[hse19$dec == 5] = "сентябрь-август"
      hse19$dec[hse19$dec == 6] = "ранее сентября"
      hse19$dec[hse19$dec == 99] = "затрудняюсь ответить"
      
      hse19$dec = as.factor(hse19$dec)
      
      dec = hse19 %>% dplyr::select(dec, adm_budget) %>% na.omit %>%  group_by(dec, adm_budget) %>% summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1)) %>% dplyr::select(dec, adm_budget, count, perc) %>% group_by(adm_budget) %>% arrange(perc)%>%
        mutate(dec=factor(dec, levels=dec))
      
      gr1 <- ggplot(dec %>% filter(dec != "затрудняюсь ответить"), aes(x = dec, y = count, fill = fct_rev(adm_budget))) +
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill")+
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "          %")), 
                  y = 0.07, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", 
                                     perc, "           %")), y = 0.8, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Распределение поступивших на бюджет\nв зависимости от давности решения о поступлении
", y = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        coord_flip()+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 10),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
    })
    output$gr1 <- renderPlot({ 
      plot(gr1())
    })
    gr2<- reactive({
      hse19$prior_1_log = grepl("^\\s*$", hse19$prior_1)
      
      hse19$prior_1_log[hse19$prior_1_log == TRUE] = "нету"
      hse19$prior_1_log[hse19$prior_1_log == FALSE] = "есть"
      hse19$prior_1_log = as.factor(hse19$prior_1_log)
      
      prior_1_log = hse19 %>% dplyr::select(prior_1_log, adm_budget) %>% na.omit() %>%  
        group_by(prior_1_log, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      gr2 <- ggplot(prior_1_log, aes(x = prior_1_log, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") +
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("",perc," %"),"")), y = 0.1, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("",perc,"%"),"")), y = 0.7, size = 3) + 
        
        #geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("n =",count,""),"")), y = 0.05, size = 3) +
        #geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("n =",count,""),"")), y = 0.65, size = 3) +
        
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Есть ли у абитуриента\nприоритетная образовательная программа?
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
    })
    output$gr2 <- renderPlot({ 
      
      plot(gr2())
    })
    gr3<- reactive({
      #val_lab(hse19$news)
      hse19$news[hse19$news == 1] = "да, слежу"
      hse19$news[hse19$news == 98] = "нет, не слежу"
      hse19$news = as.factor(hse19$news)
      
      news = hse19 %>% dplyr::select(news, adm_budget) %>% na.omit() %>%  
        group_by(news, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      gr3 <- ggplot(news, aes(x = news, y = count, fill = forcats::fct_rev(adm_budget))) + 
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill") +
        
        geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("",perc," %"),"")), y = 0.1, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("",perc,"%"),"")), y = 0.7, size = 3) + 
        
        #geom_text(aes(label = ifelse(adm_budget == "бюджет",paste("n =",count,""),"")), y = 0.05, size = 3) +
        #geom_text(aes(label = ifelse(adm_budget == "не поступил/платно",paste("n =",count,""),"")), y = 0.65, size = 3) +
        
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Следит ли у абитуриента за новостями\nНИУ ВШЭ в соц.сетях?
            ", y  = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.5), title = element_text(size = 10))
    })
    output$gr3 <- renderPlot({ 
      plot(gr3())
    })
    gr4<- reactive({
      #val_lab(hse19$uni_2)
      hse19$uni_2[hse19$uni_2 == 1] = "1 приоритетный ВУЗ"
      hse19$uni_2[hse19$uni_2 == 2] = "2 приоритетных ВУЗа"
      hse19$uni_2[hse19$uni_2 == 3] = "неопределенный приоритет"
      hse19$uni_2[hse19$uni_2 == 4] = "мне всё равно"
      hse19$uni_2 = as.factor(hse19$uni_2)
      
      uni_2 = hse19 %>% dplyr::select(uni_2, adm_budget) %>% na.omit %>%  group_by(uni_2, adm_budget) %>% summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1)) %>% dplyr::select(uni_2, adm_budget, count, perc) %>% group_by(adm_budget) %>% arrange(perc) %>%
        mutate(uni_2=factor(uni_2, levels=uni_2))
      
      gr4 <- ggplot(uni_2 %>% filter(uni_2 != 98), aes(x = uni_2, y = count, fill = fct_rev(adm_budget))) +
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill")+
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "          %")), 
                  y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", 
                                     perc, "           %")), y = 0.8, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Распределение поступивших на бюджет\nв зависимости от наличия приоритетного ВУЗа
", y = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        coord_flip()+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 10),
              plot.title = element_text(hjust = 0.9), title = element_text(size = 10))
    })
    output$gr4 <- renderPlot({ 
      plot(gr4())
    })
    
    
    graph1 <- reactive({ 
      hse19$uni_3[hse19$uni_3 == 1] = "Важно поступить на конкретное направление\nподготовки в конкретный вуз"
      hse19$uni_3[hse19$uni_3 == 2] = "Важно поступить в конкретный вуз\nна любое направление подготовки"
      hse19$uni_3[hse19$uni_3 == 3] = "Важно поступить на конкретное направление\nподготовки в любой вуз"
      hse19$uni_3[hse19$uni_3 == 4] = "Важно только получить высшее образование"
      hse19$uni_3 = as.factor(hse19$uni_3)
      
      #5 и 99 фильтрануть
      uni_3 = hse19 %>% dplyr::select(uni_3, adm_budget) %>% na.omit %>%  group_by(uni_3, adm_budget) %>% summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1)) %>% dplyr::select(uni_3, adm_budget, count, perc) %>% group_by(adm_budget) %>% arrange(perc) %>%
        mutate(uni_3=factor(uni_3, levels=uni_3))
      
      graph1 <- ggplot(uni_3 %>% filter(uni_3 != 98 & uni_3 != 5 & uni_3 != 99), aes(x = uni_3, y = count, fill = fct_rev(adm_budget))) +
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill")+
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "          %")), 
                  y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", 
                                     perc, "           %")), y = 0.8, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Распределение поступивших\nна бюджет в зависимости от\nличных приоритетов
", y = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        coord_flip()+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 1), title = element_text(size = 10))
      
    })
    output$graph1 <- renderPlot({ 
      plot(graph1())
    })
    graph2 <- reactive({
      #var_lab(hse19$Q62_r1)
      
      hse19$Q62_r1[hse19$Q62_r1 == 1] = "Совершенно не согласен"
      hse19$Q62_r1[hse19$Q62_r1 == 2] = "Скорее не согласен"
      hse19$Q62_r1[hse19$Q62_r1 == 3] = "Скорее согласен"
      hse19$Q62_r1[hse19$Q62_r1 == 4] = "Полностью согласен"
      hse19$Q62_r1 = as.factor(hse19$Q62_r1)
      
      hse19$Q62_r1 = ordered(hse19$Q62_r1, levels = c("Совершенно не согласен","Скорее не согласен","Скорее согласен","Полностью согласен"))
      
      Q62_r1 = hse19 %>% dplyr::select(Q62_r1, adm_budget) %>% na.omit() %>%  
        group_by(Q62_r1, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      graph2 <- ggplot(Q62_r1 %>% filter(Q62_r1 != 98 & Q62_r1 != 5 & Q62_r1 != 99), aes(x = Q62_r1, y = count, fill = fct_rev(adm_budget))) +
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill")+
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "          %")), 
                  y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", 
                                     perc, "           %")), y = 0.8, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Высшее образование обеспечивает человеку успешную\nкарьеру и облегчает достижение жизненных целей
", y = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        coord_flip()+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.9), title = element_text(size = 10))
    })
    
    modeling5 <- reactive({
    })
    output$graph2 <- renderPlot({ 
      plot(graph2())
    })
    graph3 <- reactive({
      hse19$Q62_r2[hse19$Q62_r2 == 1] = "Совершенно не согласен"
      hse19$Q62_r2[hse19$Q62_r2 == 2] = "Скорее не согласен"
      hse19$Q62_r2[hse19$Q62_r2 == 3] = "Скорее согласен"
      hse19$Q62_r2[hse19$Q62_r2 == 4] = "Полностью согласен"
      hse19$Q62_r2 = as.factor(hse19$Q62_r2)
      
      hse19$Q62_r2 = ordered(hse19$Q62_r2, levels = c("Совершенно не согласен","Скорее не согласен","Скорее согласен","Полностью согласен"))
      
      Q62_r2 = hse19 %>% dplyr::select(Q62_r2, adm_budget) %>% na.omit() %>%  
        group_by(Q62_r2, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      graph3 <- ggplot(Q62_r2 %>% filter(Q62_r2 != 98 & Q62_r2 != 99), aes(x = Q62_r2, y = count, fill = fct_rev(adm_budget))) +
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill")+
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "          %")), 
                  y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", 
                                     perc, "           %")), y = 0.8, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Значимость высшего образования часто преувеличивают,\nв наше время и без него можно сделать удачную\nкарьеру и устроить свою жизнь
", y = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        coord_flip()+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.9), title = element_text(size = 10))
    })  
    output$graph3 <- renderPlot({ 
      plot(graph3())
    })
    
    graph4 <- reactive({   
      hse19$Q62_r3[hse19$Q62_r3 == 1] = "Совершенно не согласен"
      hse19$Q62_r3[hse19$Q62_r3 == 2] = "Скорее не согласен"
      hse19$Q62_r3[hse19$Q62_r3 == 3] = "Скорее согласен"
      hse19$Q62_r3[hse19$Q62_r3 == 4] = "Полностью согласен"
      hse19$Q62_r3 = as.factor(hse19$Q62_r3)
      
      hse19$Q62_r3 = ordered(hse19$Q62_r3, levels = c("Совершенно не согласен","Скорее не согласен","Скорее согласен","Полностью согласен"))
      
      Q62_r3 = hse19 %>% dplyr::select(Q62_r3, adm_budget) %>% na.omit() %>%  
        group_by(Q62_r3, adm_budget) %>% 
        summarise(count = n()) %>% mutate(perc = round((count/sum(count)*100),1))
      
      graph4 <- ggplot(Q62_r3 %>% filter(Q62_r3 != 98 & Q62_r3 != 99), aes(x = Q62_r3, y = count, fill = fct_rev(adm_budget))) +
        geom_bar(stat = "identity", color = "black", alpha = 0.5, position = "fill")+
        geom_text(aes(label = ifelse(adm_budget == "бюджет", perc, "          %")), 
                  y = 0.05, size = 3) +
        geom_text(aes(label = ifelse(adm_budget == "не поступил/платно", 
                                     perc, "           %")), y = 0.8, size = 3) +
        scale_y_continuous(labels = scales::percent)+
        labs(title = "Без высшего образования человек обречен на\nнизкооплачиваемую и непрестижную работу
", y = "", x = "") +
        theme_minimal() +
        guides(fill = F)+
        coord_flip()+
        scale_fill_manual(values = wes_palette("Rushmore")[2:3])+
        theme(text = element_text(size = 11),
              plot.title = element_text(hjust = 0.9), title = element_text(size = 10))
    })
    
    
    output$graph4<- renderPlot({ 
      plot(graph4())
    })
    
}

# Run the application 
shinyApp(ui = ui, server = server)
